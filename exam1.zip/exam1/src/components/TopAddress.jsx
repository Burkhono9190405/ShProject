import React from 'react'
import '../styles/topaddress.css'
function TopAddress() {
  return (
    <div className="container">
    <div className="TopAddress">
        <h1>Billing Address</h1>
        <h1>Your Order</h1>
    </div>
    </div>
  )
}

export default TopAddress