import React from 'react'
import '../styles/longcard.css'

function LongCard() {
    return (
        <section></section>
    )
}

export default LongCard