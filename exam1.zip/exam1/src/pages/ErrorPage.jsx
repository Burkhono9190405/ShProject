import React from 'react'

function ErrorPage() {
  return (
    <div>This page is not foundddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd</div>
  )
}

export default ErrorPage